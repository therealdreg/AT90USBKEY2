Please note that all serie 6 firmware packages are fully compatible with the serie 7 devices.

Please note that the device part of the serie 7 firmware packages are fully compatible with the serie 6 devices.

Please find hereunder the part numbers of each family:

--------------------------------------------------------------------
	   |							    |
Serie 2	   |AT90USB162,AT90USB82, ATmega32U2, ATmega16U2, ATmega8U2 |  				
	   |							    |
--------------------------------------------------------------------
	   |							    |
Serie 4    |ATmega32U4, ATmega16U4				    |
	   |							    |
--------------------------------------------------------------------
	   |							    |
Serie 6	   |AT90USB1286, AT90USB646, ATmega32U6			    |
	   |`							    |
--------------------------------------------------------------------
	   |							    |
Serie 7	   |AT90USB1287, AT90USB647				    |
	   |							    |
--------------------------------------------------------------------