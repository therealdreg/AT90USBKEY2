/*This file has been prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file is a template for writing C software programs.
//!
//!  This file contains the C51 RAM called CRAM management routines which are
//!  used for Mass storage when doing ISP
//!  This file calls routines of the cram_mem.c file
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  AT90USB1287, AT90USB1286, AT90USB647, AT90USB646
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _HOSTMEM_H_
#define _HOSTMEM_H_

#include "conf/conf_access.h"
#include "modules/control_access/ctrl_status.h"
#include "conf/conf_usb.h"


#ifndef HOST_SECTOR_SIZE
#define HOST_SECTOR_SIZE   512   //default sector size is 512 bytes
#endif

extern   U8 host_ms_max_lun;
extern   U8 host_selected_lun;

#if (USB_HUB_SUPPORT==ENABLE)
   #ifndef USB_MAX_DMS_NUMBER
      #define USB_MAX_DMS_NUMBER    MAX_DEVICE_IN_USB_TREE-1
   #endif
#else
   #define USB_MAX_DMS_NUMBER 1         
#endif
         
typedef struct
{
   U8 device_index;
   U8 pipe_in;
   U8 pipe_out;
   U8 nb_lun;
} S_dms_device;

extern   S_dms_device dms[USB_MAX_DMS_NUMBER];
extern   U8  dms_connected;
extern   U8  dms_selected;

#define Select_dms(n)   (dms_selected=n)
#define DMS_pipe_in()   (dms[dms_selected].pipe_in)
#define DMS_pipe_out()  (dms[dms_selected].pipe_out)





#define Host_getlun()   (host_get_lun())

//_____ D E F I N I T I O N S ______________________________________________

//---- CONTROL FONCTIONS ----

Ctrl_status    host_test_unit_ready(U8 lun);
Ctrl_status    host_read_capacity( U8 lun, U32 _MEM_TYPE_SLOW_ *u32_nb_sector );
Bool           host_wr_protect(U8 lun);
Bool           host_removal(void);
U8             host_get_lun(void);
U8             host_ms_read_capacity    (U32*);
U8             host_ms_test_unit_ready  (void);
U8             host_ms_mode_sense_6     (void);
U8             host_ms_inquiry          (void);
U8             host_ms_request_sense    (void);
void           host_ms_stall_management (void);
Ctrl_status    host_read_format_capacity(U8 lun);


//---- RAM 2 MEM functions for file system access ----------------------------
Ctrl_status host_read_10_ram( U8 lun,U32 addr, U8 *ram );
Ctrl_status host_write_10_ram( U8 lun,U32 addr, U8 *ram );




#endif   // _HOSTMEM_H_
