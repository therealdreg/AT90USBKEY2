/*This file has been prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief  This file contains the interface routines of virtual memory.
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  AT90USB1287, AT90USB1286, AT90USB647, AT90USB646
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//_____  I N C L U D E S ___________________________________________________

#include "config.h"                         // system configuration
#include "conf/conf_usb.h"
#include "host_mem.h"
#include "conf/conf_access.h"
#include "lib_mcu/usb/usb_drv.h"
#include "modules/usb/host_chap9/usb_host_enum.h"
#include "modules/usb/host_chap9/usb_host_task.h"
#include "modules/scsi_decoder/scsi_decoder.h"

//_____ D E F I N I T I O N ________________________________________________


U8    host_ms_max_lun;
U8    host_selected_lun;
U16   device_block_size;
U8    device_last_sense;
U8    device_ms_unit_ready = 0;
U8    buf_cmd[31];
static U8 dCBWTag;

S_dms_device dms[USB_MAX_DMS_NUMBER];
U8  dms_connected=0;
U8  dms_selected=0;


//_____ D E C L A R A T I O N ______________________________________________



//! This fonction checks the USB Host memory presence
//!
/*
Bool host_is_present(void)
{
   if(Is_host_device_ready())
   {
      if (HOST_TRUE == host_ms_test_unit_ready()) { return TRUE; }
      else                                        { return FALSE;}
   }
   else
   {
      return FALSE;
   }
}
*/
   
void  host_dms_compute_device_lun(U8 lun)
{
   U8 j=0;

   for(dms_selected=0;dms_selected<dms_connected;dms_selected++)
   {
      j+=dms[dms_selected].nb_lun;
      if (lun<j)
      {
         host_selected_lun=lun-(j-dms[dms_selected].nb_lun);
         Host_select_device(dms[dms_selected].device_index);
         break;
      }
   }   
}   

//! This fonction returns the number of LUN of the device mass storage connected to the host
//!
//! @return   U8 (the number of LUT)
U8 host_get_lun()
{
   if(Is_host_ms_configured())
   {
      data_stage[0] = 0; // Caution init to zero by default, in case host_ms_get_max_lun() is stalled by the DMS
      Host_select_device(dms[dms_selected].device_index);
      host_ms_get_max_lun();
      return  data_stage[0]+1;
   }
   else  return 0;
}

//! This fonction test the state of memory, and start the initialisation of the memory
//!
//! @return                          Ctrl_status
//!   It is ready              ->    CTRL_GOOD
//!   Memory unplug            ->    CTRL_NO_PRESENT
//!   Not initialize or change ->    CTRL_BUSY
//!   A error occur            ->    CTRL_FAIL
//!
Ctrl_status host_test_unit_ready(U8 lun)
{
   U16   nb;
   U8    status;

   host_dms_compute_device_lun(lun);

   if( !Is_host_ms_configured() ) 
      return CTRL_GOOD;

   buf_cmd[0]=(0x55);                       //  0 - 0x55
   buf_cmd[1]=(0x53);                       //  1 - 0x53
   buf_cmd[2]=(0x42);                       //  2 - 0x42
   buf_cmd[3]=(0x43);                       //  3 - 0x43
   buf_cmd[4]=(dCBWTag++);                  //  4 - MSB0(dCBWTag)
   buf_cmd[5]=(0x00);                       //  5 - MSB1(dCBWTag)
   buf_cmd[6]=(0x00);                       //  6 - MSB2(dCBWTag)
   buf_cmd[7]=(0x00);                       //  7 - MSB3(dCBWTag)
   buf_cmd[8]=(0x00);                       //  8 - MSB0(dCBWDataTransferLength)
   buf_cmd[9]=(0x00);                       //  9 - MSB1(dCBWDataTransferLength)
   buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
   buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
   buf_cmd[12]=(SBC_CMD_DIR_OUT);            // 12 - bmCBWFlags
   buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
   buf_cmd[14]=(0x06);                       // 14 - bCBWCBLength
   buf_cmd[15]=(SBC_CMD_TEST_UNIT_READY);    // 15 - CBWCB0 - Operation Code (0x00)
   buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - reserved
   buf_cmd[17]=(0x00);                       // 17 - CBWCB2 - reserved
   buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - reserved
   buf_cmd[19]=(0x00);                       // 19 - CBWCB4 - reserved
   buf_cmd[20]=(0x00);                       // 20 - CBWCB5 - Control
   buf_cmd[21]=(0x00);                       // 21
   buf_cmd[22]=(0x00);                       // 22
   buf_cmd[23]=(0x00);                       // 23
   buf_cmd[24]=(0x00);                       // 24
   buf_cmd[25]=(0x00);                       // 25
   buf_cmd[26]=(0x00);                       // 26
   buf_cmd[27]=(0x00);                       // 27
   buf_cmd[28]=(0x00);                       // 28
   buf_cmd[29]=(0x00);                       // 29
   buf_cmd[30]=(0x00);                       // 30

   host_send_data(DMS_pipe_out(), 31, buf_cmd);

   nb=31;
   status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);
   if (status==PIPE_STALL)
   {
      host_ms_stall_management();
      return CTRL_FAIL;
   }
   if (buf_cmd[12] != COMMAND_PASSED)
   {
      host_ms_request_sense();
      return CTRL_FAIL;
   }
   Host_set_device_ready();
   device_ms_unit_ready = 1;
   return CTRL_GOOD;
}


//! This fonction returns the address of the last valid sector.
//!
//! @return *u16_nb_sector number of sector (sector = 512B)
//! @return                          Ctrl_status
//!   It is ready              ->    CTRL_GOOD
//!   Memory unplug            ->    CTRL_NO_PRESENT
//!   Not initialize or change ->    CTRL_BUSY
//!   A error occur            ->    CTRL_FAIL
//!
Ctrl_status host_read_capacity(U8 lun, U32 _MEM_TYPE_SLOW_ *u32_nb_sector )
{

U16   nb;
U8    status;


   host_dms_compute_device_lun(lun);
   /*
   host_ms_inquiry();

   for(nb=0;nb<5;nb++)
   {
      if(CTRL_GOOD==host_read_format_capacity(lun))
      {
         break;
      }
   }*/
   if(Is_host_ms_configured())
   {
      buf_cmd[0]=(0x55);                        //  0 - 0x55
      buf_cmd[1]=(0x53);                        //  1 - 0x53
      buf_cmd[2]=(0x42);                        //  2 - 0x42
      buf_cmd[3]=(0x43);                        //  3 - 0x43
      buf_cmd[4]=((dCBWTag++));                 //  4 - MSB0(dCBWTag)
      buf_cmd[5]=(0x00);                        //  5 - MSB1(dCBWTag)
      buf_cmd[6]=(0x00);                        //  6 - MSB2(dCBWTag)
      buf_cmd[7]=(0x00);                        //  7 - MSB3(dCBWTag)
      buf_cmd[8]=(0x08);                        //  8 - MSB0(dCBWDataTransferLength)
      buf_cmd[9]=(0x00);                        //  9 - MSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x0A);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_READ_CAPACITY);      // 15 - CBWCB0 - Operation Code (0x25)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - relative address
      buf_cmd[17]=(0x00);                       // 17 - CBWCB2 - MSB3(Logical Block Address)
      buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - MSB2(Logical Block Address)
      buf_cmd[19]=(0x00);                       // 19 - CBWCB4 - MSB1(Logical Block Address)
      buf_cmd[20]=(0x00);                       // 20 - CBWCB5 - MSB0(Logical Block Address)
      buf_cmd[21]=(0x00);                       // 21 - CBWCB6 - reserved
      buf_cmd[22]=(0x00);                       // 22 - CBWCB7 - reserved
      buf_cmd[23]=(0x00);                       // 23 - CBWCB8 - PMI
      buf_cmd[24]=(0x00);                       // 24 - CBWCB9 - Control
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30

      host_send_data(DMS_pipe_out(), 31, buf_cmd);
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      if(status==PIPE_STALL)
      {
         host_ms_stall_management();
         return CTRL_FAIL;
      }
      else
      {
         MSB0(*u32_nb_sector)       = buf_cmd[0];
         MSB1(*u32_nb_sector)       = buf_cmd[1];
         MSB2(*u32_nb_sector)       = buf_cmd[2];
         MSB3(*u32_nb_sector)       = buf_cmd[3];
         MSB(device_block_size)     = buf_cmd[6];
         LSB(device_block_size)     = buf_cmd[7];
      }
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);
      if (buf_cmd[12] == COMMAND_PASSED) { Host_set_device_ready(); return CTRL_GOOD;  }
      else                         { return CTRL_FAIL; }
   }
   else
   {
      return CTRL_FAIL;
   }
}


//! This fonction return is the write protected mode
//!
//! Only used by memory removal with a HARDWARE SPECIFIC write protected detection
//! !!! The customer must be unplug the card for change this write protected mode.
//!
//! @return TRUE  -> the memory is protected
//!
Bool  host_wr_protect(U8 lun)
{

U16   nb;
U8    status;
U8 write_code;

   host_dms_compute_device_lun(lun);


   if(Is_host_ms_configured())
   {
      buf_cmd[0]=(0x55);                       //  0 - 0x55
      buf_cmd[1]=(0x53);                       //  1 - 0x53
      buf_cmd[2]=(0x42);                       //  2 - 0x42
      buf_cmd[3]=(0x43);                       //  3 - 0x43
      buf_cmd[4]=((dCBWTag++));                //  4 - MSB0(dCBWTag)
      buf_cmd[5]=(0x00);                       //  5 - MSB1(dCBWTag)
      buf_cmd[6]=(0x00);                       //  6 - MSB2(dCBWTag)
      buf_cmd[7]=(0x00);                       //  7 - MSB3(dCBWTag)
      buf_cmd[8]=(0x0C);                       //  8 - MSB0(dCBWDataTransferLength)
      buf_cmd[9]=(0x00);                       //  9 - MSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x06);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_MODE_SENSE_6);       // 15 - CBWCB0 - Operation Code (0x1A)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - Option
      buf_cmd[17]=(0x3F);                       // 17 - CBWCB2 - Page Code 3F = return all mode pages
      buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - reserved
      buf_cmd[19]=(0x0C);                       // 19 - CBWCB4 - Allocation Length
      buf_cmd[20]=(0x00);                       // 20 - CBWCB5 - Control
      buf_cmd[21]=(0x00);                       // 21
      buf_cmd[22]=(0x00);                       // 22
      buf_cmd[23]=(0x00);                       // 23
      buf_cmd[24]=(0x00);                       // 24
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30
      host_send_data(DMS_pipe_out(), 31, buf_cmd);
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);
      write_code  = buf_cmd[2];
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      if (status==PIPE_STALL)
      {
         host_ms_stall_management();
         return FALSE;
      }
      else
      {
         if (write_code != 0x80) 
         {return FALSE;}
         else
         {return TRUE; }        
      }
   }
   else
   {
      return TRUE;
   }
   return TRUE; //just for warning elimination
}


//! This fonction inform about the memory type
//!
//! @return FASLE  -> The memory isn't removal
//!
Bool  host_removal(void)
{
   return Is_ms_connected();
}



//------------ STANDARD FONCTION for open in read/write mode the device ---------------


//! host_ms_inquiry.
//!
//! This function reads inquiry data format of the device
//!
//! @warning Code:xx bytes (function code length)
//!
//! @param none
//!
//! @return none
//!
U8 host_ms_inquiry ()                                 // INQUIRY
{
U16   nb;


   if(Is_host_ms_configured())
   {
      buf_cmd[0]= (0x55);                       //  0 - 0x55
      buf_cmd[1]= (0x53);                       //  1 - 0x53
      buf_cmd[2]= (0x42);                       //  2 - 0x42
      buf_cmd[3]= (0x43);                       //  3 - 0x43
      buf_cmd[4]= ((dCBWTag++));                //  4 - MSB0(dCBWTag)
      buf_cmd[5]= (0x00);                       //  5 - MSB1(dCBWTag)
      buf_cmd[6]= (0x00);                       //  6 - MSB2(dCBWTag)
      buf_cmd[7]= (0x00);                       //  7 - MSB3(dCBWTag)
      buf_cmd[8]= (0x24);                       //  8 - MSB0(dCBWDataTransferLength)
      buf_cmd[9]= (0x00);                       //  9 - MSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x06);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_INQUIRY);            // 15 - CBWCB0 - Operation Code (0x12)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - Option
      buf_cmd[17]=(0x00);                       // 17 - CBWCB2 - Page or operation code
      buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - reserved
      buf_cmd[19]=(0x24);                       // 19 - CBWCB4 - Allocation Length
      buf_cmd[20]=(0x00);                       // 20 - CBWCW5 - Control
      buf_cmd[21]=(0x00);                       // 21
      buf_cmd[22]=(0x00);                       // 22
      buf_cmd[23]=(0x00);                       // 23
      buf_cmd[24]=(0x00);                       // 24
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30

      // Send command
      host_send_data(DMS_pipe_out(), 31, buf_cmd);


      // Transfer data ...
      nb=31;
      host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      //Get CBW...
      nb=31;
      host_get_data(DMS_pipe_in(),&nb,buf_cmd);


      if (buf_cmd[12] == COMMAND_PASSED) { return CTRL_GOOD; }
      else  { return CTRL_FAIL; }
   }
   else
   {
      return CTRL_FAIL;
   }
}

//! host_ms_request_sense.
//!
//! This function reads inquiry data format of the device
//!
//! @warning Code:xx bytes (function code length)
//!
//! @param none
//!
//! @return none
//!
U8 host_ms_request_sense ()                           // REQUEST SENSE
{
   U16   nb;
   U8    status;
   volatile U32   delay;

   if(Is_host_ms_configured())
   {

      buf_cmd[0]= (0x55);                       //  0 - 0x55
      buf_cmd[1]= (0x53);                       //  1 - 0x53
      buf_cmd[2]= (0x42);                       //  2 - 0x42
      buf_cmd[3]= (0x43);                       //  3 - 0x43
      buf_cmd[4]= ((dCBWTag++));                //  4 - MSB0(dCBWTag)
      buf_cmd[5]= (0x00);                       //  5 - MSB1(dCBWTag)
      buf_cmd[6]= (0x00);                       //  6 - MSB2(dCBWTag)
      buf_cmd[7]= (0x00);                       //  7 - MSB3(dCBWTag)
      buf_cmd[8]= (0x12);                       //  8 - MSB0(dCBWDataTransferLength)
      buf_cmd[9]= (0x00);                       //  9 - MSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x06);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_REQUEST_SENSE);      // 15 - CBWCB0 - Operation Code (0x03)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - reserved
      buf_cmd[17]=(0x00);                       // 17 - CBWCB2 - reserved
      buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - reserved
      buf_cmd[19]=(0x12);                       // 19 - CBWCB4 - Allocation Length
      buf_cmd[20]=(0x00);                       // 20 - CBWCW5 - Control
      buf_cmd[21]=(0x00);                       // 21
      buf_cmd[22]=(0x00);                       // 22
      buf_cmd[23]=(0x00);                       // 23
      buf_cmd[24]=(0x00);                       // 24
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30

      host_send_data(DMS_pipe_out(), 31, buf_cmd);

      for(delay=0;delay<100000;delay++);
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      if(status==PIPE_STALL)
      {
         host_ms_stall_management();
         return CTRL_FAIL;
      }
      else
      {
         device_last_sense = (0x0F & buf_cmd[2]);
      }

      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      switch (device_last_sense)
      {
         case SBC_SENSE_KEY_NO_SENSE:
         case SBC_SENSE_KEY_NOT_READY:
         case SBC_SENSE_KEY_UNIT_ATTENTION:
         case SBC_SENSE_KEY_HARDWARE_ERROR:
         case SBC_SENSE_KEY_DATA_PROTECT:
              break;
         default:
              device_last_sense = SBC_SENSE_KEY_NO_SENSE;
              break;
      }
      return (device_last_sense);
   }
   else
   {
      return CTRL_FAIL;
   }
}


//! host_ms_stall_management.
//!
//! This function writes data from the usb memory
//!
//! @warning Code:xx bytes (function code length)
//!
//! @param none
//!
//! @return none
//!
void host_ms_stall_management()
{
U8 dummy;
U16 nb;


   dummy = Host_get_endpoint_number() | ~MSK_EP_DIR;
   host_clear_endpoint_feature(dummy);
   Host_select_pipe(DMS_pipe_in());
   Host_ack_stall();
   Host_reset_pipe_data_toggle();

   //Get CBW...
   nb=31;
   host_get_data(DMS_pipe_in(),&nb,buf_cmd);

   host_ms_request_sense();
}


//! This function reads data memory and loads these data into the ram memory
//!
//! @param adrr sector address to read in memory
//! @param *ram ram pointer target addr
//!
//! @return Ctrl_status
//!
Ctrl_status host_read_10_ram(  U8 lun, U32 addr, U8 *ram )
{


U16   nb;
U8    status;

   host_dms_compute_device_lun(lun);
   if(Is_host_ms_configured())
   {
      // Build command buffer
      buf_cmd[0]=(0x55);                       //  0 - 0x55
      buf_cmd[1]=(0x53);                       //  1 - 0x53
      buf_cmd[2]=(0x42);                       //  2 - 0x42
      buf_cmd[3]=(0x43);                       //  3 - 0x43
      buf_cmd[4]=(dCBWTag++);                  //  4 - MSB0(dCBWTag)
      buf_cmd[5]=(0x00);                       //  5 - MSB1(dCBWTag)
      buf_cmd[6]= (0x00);                       //  6 - MSB2(dCBWTag)
      buf_cmd[7]= (0x00);                       //  7 - MSB3(dCBWTag)
      buf_cmd[8]= ((U8)HOST_SECTOR_SIZE);       //  8 - LSB0(dCBWDataTransferLength)
      buf_cmd[9]= ((U16)HOST_SECTOR_SIZE>>8);   //  9 - LSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - LSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - LSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x0A);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_READ_10);            // 15 - CBWCB0 - Operation Code (0x28)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - option
      buf_cmd[17]=(MSB0(addr));                 // 17 - CBWCB2 - MSB3(Logical Block Address)
      buf_cmd[18]=(MSB1(addr));                 // 18 - CBWCB3 - MSB2(Logical Block Address)
      buf_cmd[19]=(MSB2(addr));                 // 19 - CBWCB4 - MSB1(Logical Block Address)
      buf_cmd[20]=(MSB3(addr));                 // 20 - CBWCB5 - MSB0(Logical Block Address)
      buf_cmd[21]=(0x00);                       // 21 - CBWCB6 - reserved
      buf_cmd[22]=(0x00);                       // 22 - CBWCB7 - MSB1(Transfer Length)
      buf_cmd[23]=(0x01);                       // 23 - CBWCB8 - MSB0(Transfer Length 1 sector)
      buf_cmd[24]=(0x00);                       // 24 - CBWCB9 - Control
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30
      // Send command
      status = host_send_data(DMS_pipe_out(), 31, buf_cmd)==PIPE_TIMEOUT;
      // Transfer data ...
      nb=HOST_SECTOR_SIZE;
      status = host_get_data(DMS_pipe_in(),&nb,ram);
      if(status==PIPE_STALL)
      {
         host_ms_stall_management();
         return CTRL_FAIL;
      }

      // Get CBW...
      nb=31;
      host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      if (buf_cmd[12] == COMMAND_PASSED) { return CTRL_GOOD; }
      else  { return CTRL_FAIL; }
   }
   else
   {
      return CTRL_FAIL;
   }
}


Ctrl_status host_write_10_ram( U8 lun, U32 addr, U8 *ram )
{
   U16   nb;
   U8    status;
   
   host_dms_compute_device_lun(lun);
   if(Is_host_ms_configured())
   {
      // Build command buffer
      buf_cmd[0]= (0x55);                       //  0 - 0x55
      buf_cmd[1]= (0x53);                       //  1 - 0x53
      buf_cmd[2]= (0x42);                       //  2 - 0x42
      buf_cmd[3]= (0x43);                       //  3 - 0x43
      buf_cmd[4]= ((dCBWTag++));                //  4 - MSB0(dCBWTag)
      buf_cmd[5]= (0x00);                       //  5 - MSB1(dCBWTag)
      buf_cmd[6]= (0x00);                       //  6 - MSB2(dCBWTag)
      buf_cmd[7]= (0x00);                       //  7 - MSB3(dCBWTag)
      buf_cmd[8]= ((U8)HOST_SECTOR_SIZE);       //  8 - LSB0(dCBWDataTransferLength)
      buf_cmd[9]= ((U16)HOST_SECTOR_SIZE>>8);   //  9 - LSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - LSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - LSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_OUT);            // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);          // 13 - bCBWLUN
      buf_cmd[14]=(0x0A);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_WRITE_10);           // 15 - CBWCB0 - Operation Code (0x28)
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - option
      buf_cmd[17]=(MSB0(addr));                  // 17 - CBWCB2 - MSB3(Logical Block Address)
      buf_cmd[18]=(MSB1(addr));                 // 18 - CBWCB3 - MSB2(Logical Block Address)
      buf_cmd[19]=(MSB2(addr));                 // 19 - CBWCB4 - MSB1(Logical Block Address)
      buf_cmd[20]=(MSB3(addr));                 // 20 - CBWCB5 - MSB0(Logical Block Address)
      buf_cmd[21]=(0x00);                       // 21 - CBWCB6 - reserved
      buf_cmd[22]=(0x00);                         // 22 - CBWCB7 - MSB1(Transfer Length)
      buf_cmd[23]=(0x01);                         // 23 - CBWCB8 - MSB0(Transfer Length 1 sector)
      buf_cmd[24]=(0x00);                       // 24 - CBWCB9 - Control
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30
      // Send command
      host_send_data(DMS_pipe_out(), 31, buf_cmd);
      // Transfer data ...
      nb=HOST_SECTOR_SIZE;
      status = host_send_data(DMS_pipe_out(),nb,ram);
      if(status==PIPE_STALL)
      {
         host_ms_stall_management();
         return CTRL_FAIL;
      }

      //to get CBW...
      nb=31;
      host_get_data(DMS_pipe_in(),&nb,buf_cmd);

   if (buf_cmd[12] == COMMAND_PASSED) { return CTRL_GOOD; }
   else  { return CTRL_FAIL; }
   }
   else
   {
      return CTRL_FAIL;
   }   
}

//! This fonction generates a read format capacity SCSI request to the DMS connected
//!
//! @return                          Ctrl_status
//!   It is ready              ->    CTRL_GOOD
//!   Memory unplug            ->    CTRL_NO_PRESENT
//!   Not initialize or change ->    CTRL_BUSY
//!   A error occur            ->    CTRL_FAIL
//!
Ctrl_status host_read_format_capacity(U8 lun)
{

U16   nb;
U8    status;


   host_dms_compute_device_lun(lun);
   if(Is_host_ms_configured())
   {
      buf_cmd[0]=(0x55);                        //  0 - 0x55
      buf_cmd[1]=(0x53);                        //  1 - 0x53
      buf_cmd[2]=(0x42);                        //  2 - 0x42
      buf_cmd[3]=(0x43);                        //  3 - 0x43
      buf_cmd[4]=((dCBWTag++));                 //  4 - MSB0(dCBWTag)
      buf_cmd[5]=(0x00);                        //  5 - MSB1(dCBWTag)
      buf_cmd[6]=(0x00);                        //  6 - MSB2(dCBWTag)
      buf_cmd[7]=(0x00);                        //  7 - MSB3(dCBWTag)
      buf_cmd[8]=(0xFC);                        //  8 - MSB0(dCBWDataTransferLength)
      buf_cmd[9]=(0x00);                        //  9 - MSB1(dCBWDataTransferLength)
      buf_cmd[10]=(0x00);                       // 10 - MSB2(dCBWDataTransferLength)
      buf_cmd[11]=(0x00);                       // 11 - MSB3(dCBWDataTransferLength)
      buf_cmd[12]=(SBC_CMD_DIR_IN);             // 12 - bmCBWFlags
      buf_cmd[13]=(host_selected_lun);                        // 13 - bCBWLUN
      buf_cmd[14]=(0x0C);                       // 14 - bCBWCBLength
      buf_cmd[15]=(SBC_CMD_READ_FORMAT_CAPACITY); // 15 - CBWCB0 - Operation Code ()
      buf_cmd[16]=(0x00);                       // 16 - CBWCB1 - relative address
      buf_cmd[17]=(0x00);                       // 17 - CBWCB2 - MSB3(Logical Block Address)
      buf_cmd[18]=(0x00);                       // 18 - CBWCB3 - MSB2(Logical Block Address)
      buf_cmd[19]=(0x00);                       // 19 - CBWCB4 - MSB1(Logical Block Address)
      buf_cmd[20]=(0x00);                       // 20 - CBWCB5 - MSB0(Logical Block Address)
      buf_cmd[21]=(0x00);                       // 21 - CBWCB6 - reserved
      buf_cmd[22]=(0x00);                       // 22 - CBWCB7 - reserved
      buf_cmd[23]=(0xFC);                       // 23 - CBWCB8 - PMI
      buf_cmd[24]=(0x00);                       // 24 - CBWCB9 - Control
      buf_cmd[25]=(0x00);                       // 25
      buf_cmd[26]=(0x00);                       // 26
      buf_cmd[27]=(0x00);                       // 27
      buf_cmd[28]=(0x00);                       // 28
      buf_cmd[29]=(0x00);                       // 29
      buf_cmd[30]=(0x00);                       // 30

      host_send_data(DMS_pipe_out(), 31, buf_cmd);
      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);

      if(status==PIPE_STALL)
      {
         host_ms_stall_management();
         return CTRL_FAIL;
      }

      nb=31;
      status=host_get_data(DMS_pipe_in(),&nb,buf_cmd);
      if(status==PIPE_GOOD) return CTRL_GOOD;
   }
   else
   {
      return CTRL_FAIL;
   }
   return CTRL_FAIL;
}
