/*This file has been prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file contains the function declarations
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  AT90USB1287, AT90USB1286, AT90USB647, AT90USB646
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _USHELL_TASK_H_
#define _USHELL_TASK_H_

//_____ I N C L U D E S ____________________________________________________


#include "config.h"
#include "modules/file_system/fs_com.h"

//_____ M A C R O S ________________________________________________________


// Commands shell
#define CMD_NONE           0x00
#define CMD_MOUNT          0x01
#define CMD_LS             0x02
#define CMD_CD             0x03
#define CMD_UP             0x04
#define CMD_CAT            0x05
#define CMD_HELP           0x06
#define CMD_MKDIR          0x07
#define CMD_TOUCH          0x08
#define CMD_RM             0x09
#define CMD_APPEND         0x0A
#define CMD_NB_DRIVE       0x0B
#define CMD_SET_ID         0x0C
#define CMD_GOTO_ID        0x0D
#define CMD_CP             0x0E
#define CMD_DF             0x0F
#define CMD_MV             0x10
#define CMD_FORMAT         0x11
#define CMD_RM_ALL         0x12
#define CMD_DELTREE        0x13
#define CMD_DFU_ERASE      0x14
#define CMD_DFU_LOAD       0x15
#define CMD_DFU_START      0x16
#define CMD_LS_USB         0x17
#define CMD_REBOOT         0x18
#define CMD_HID_ENTER_DFU  0x19
#define CMD_HID_GET_INFO   0x1A
#define CMD_USB_SUSPEND    0x1B
#define CMD_USB_RESUME     0x1C
#define CMD_USB_FORCE_ENUM 0x1D
#define CMD_LS_MORE        0x1E
#define CMD_CAT_MORE       0x1F


// Special char values
#define CR                 0x0D
#define LF                 0x0A
#define CTRL_Q             0x11
#define CTRL_C             0x03
#define BKSPACE_CHAR       0x08
#define ABORT_CHAR         CTRL_C
#define QUIT_APPEND        CTRL_Q
#define HISTORY_CHAR       '!'
#define QUIT_MORE          'q'
#define CONTINUE_MORE      ' '

// String values for commands
#define STR_CD             "cd"
#define STR_MOUNT          "mount"
#define STR_CP             "cp"
#define STR_LS             "ls"
#define STR_LS_MORE        "ls|more"
#define STR_RM             "rm"
#define STR_RM_ALL         "rm*"
#define STR_DF             "df"
#define STR_MKDIR          "mkdir"
#define STR_TOUCH          "touch"
#define STR_APPEND         "append"
#define STR_CAT            "cat"
#define STR_CAT_MORE       "cat|more"
#define STR_UP             "cd.."
#define STR_DISK           "disk"
#define STR_MARK           "mark"
#define STR_GOTO           "goto"
#define STR_MV             "mv"
#define STR_A              "a:"
#define STR_B              "b:"
#define STR_C              "c:"
#define STR_D              "d:"
#define STR_E              "e:"
#define STR_F              "f:"
#define STR_HELP           "help"
#define STR_FORMAT         "format"
#define STR_DELTREE        "deltree"
#define STR_REBOOT         "reboot"

#define STR_DFU_ERASE      "dfu_erase"
#define STR_DFU_LOAD       "dfu_prog"
#define STR_DFU_START      "dfu_start"

#define STR_LS_USB         "lsusb"
#define STR_USB_SUSPEND    "suspend"
#define STR_USB_RESUME     "resume"
#define STR_USB_FORCE_ENUM "enumerate"

#define STR_HID_GET_INFO   "hid_get"
#define STR_HID_ENTER_DFU  "hid_dfu"

// String messages
#define MSG_PROMPT         "$>"
#define MSG_WELCOME        "\x0C\n\r------------------------\n\rATMEL AT90USBxxx uShell\n\r------------------------\n\r"
#define MSG_EXIT           "\x0C\n\r------------------------\n\ruShell not available\n\r------------------------\n\r"

#define MSG_ER_PASTE          "Paste Fail\n\r"
#define MSG_ER_MOUNT          "unable to mount drive\n\r"
#define MSG_ER_DRIVE          "Drive does not exist\n\r"
#define MSG_ER_RM             "can not erase, if the name is a directory, check it is empty\n\r"
#define MSG_ER_UNKNOWM_FILE   "Unknown file\n\r"
#define MSG_ER_CMD_NOT_FOUND  " Command not found\n\r"
#define MSG_ER_FORMAT         "Format fails\n\r"
#define MSG_APPEND_WELCOME    "\n\rSimple text editor, enter char to append ^q to exit and save\n\r"
#define MSG_HELP    "\
Commands summary\n\r\
 a: , b: ... goto selected drive             cat filename\n\r\
 cd dirname                                  cd..\n\r\
 ls                                          mount disk(a,b,..)\n\r\
 ls|more                                     cat|more\n\r\
 touch filename                              mkdir dirname\n\r\
 append filename                             disk: get number of drives\n\r\
 mark: bookmark current directory            goto: goto bookmark\n\r\
 cp filename: copy filename to bookmark      df: get free space information\n\r\
 rm filename: erase file or empty directory  cat filename\n\r\
 format drivename, with drivename: a, b...   rm*: rm *\n\r\
 deltree dirname                             \n\r\
 dfu_erase                                   dfu_prog filename\n\r\
 dfu_start\n\r\
 hid_dfu                                     hid_get\n\r\
 lsusb: get Usb information                  suspend: suspend USB Host\n\r\
 resume: resume USB host bus                 enumerate: force USB reset and enum\n\r\
 !: command history\n\r\
 reboot\n\r\
"
#define MSG_NO_DEVICE         "No supported device connected\n\r"
#define MSG_REMOTE_WAKEUP_OK  "Device supports remote wakeup\n\r"
#define MSG_REMOTE_WAKEUP_KO  "Device does not support remote wakeup\n\r"
#define MSG_DEVICE_STATUS_SELF_POWERED      "Device is Self Powered\n\r"
#define MSG_BUS_POWERED       "Device is Bus Powered\n\r"
#define MSG_USB_SUSPENDED     "USB is suspended!\n\r"
#define MSG_OK                "ok\n\r"
#define MSG_KO                "KO\n\r"
#define MSG_DEVICE_FULL_SPEED "Device is full speed\n\r"
#define MSG_DEVICE_LOW_SPEED  "Device is low speed\n\r"


//_____ D E C L A R A T I O N S ____________________________________________


#endif /* _USHELL_TASK_H_ */

