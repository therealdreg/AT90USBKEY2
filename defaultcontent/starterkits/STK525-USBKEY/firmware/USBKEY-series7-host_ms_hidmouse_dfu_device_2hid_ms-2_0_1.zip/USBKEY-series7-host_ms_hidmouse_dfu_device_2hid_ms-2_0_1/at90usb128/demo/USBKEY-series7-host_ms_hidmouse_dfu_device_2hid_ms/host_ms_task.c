/*This file has been prepared for Doxygen automatic documentation generation.*/
//! \file *********************************************************************
//!
//! \brief This file contains the function declarations for usb host mass storage  task application
//!
//! - Compiler:           IAR EWAVR and GNU GCC for AVR
//! - Supported devices:  AT90USB1287, AT90USB1286, AT90USB647, AT90USB646
//!
//! \author               Atmel Corporation: http://www.atmel.com \n
//!                       Support and FAQ: http://support.atmel.no/
//!
//! ***************************************************************************

/* Copyright (c) 2007, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//_____  I N C L U D E S ___________________________________________________

#include "config.h"
#include "conf_usb.h"
// File system includes required for SYNC mode
#if (HOST_SYNC_MODE==ENABLE)
   #include "modules/file_system/fat.h"
   #include "modules/file_system/fs_com.h"
   #include "modules/file_system/navigation.h"
   #include "modules/file_system/file.h"
#endif
#include "host_ms_task.h"
#include "modules/usb/host_chap9/usb_host_task.h"
#include "modules/usb/host_chap9/usb_host_enum.h"
#include "lib_mcu/usb/usb_drv.h"
#include "lib_mem/host_mem/host_mem.h"
#include "modules/file_system/fat.h"
#include "modules/file_system/navigation.h"
#include "modules/file_system/file.h"
#include "modules/file_system/nav_utils.h"
#include "modules/ushell/ushell_task.h"


//_____ M A C R O S ________________________________________________________

#ifndef HOST_SYNC_MODE
#warning HOST_SYNC_MODE not defined as ENABLE or DISABLE, using DISABLE...
#define HOST_SYNC_MODE  DISABLE
#endif

#ifndef LOG_STR_CODE
#define LOG_STR_CODE(str)
#else
U8 code log_ms_connect[]="Mass Storage Connected";
#endif

//_____ D E C L A R A T I O N S ____________________________________________

//! Physical Pipe number associated to device
//! mass Storage OUT endpoint
U8  pipe_ms_out;

//! Physical Pipe number associated to device
//! mass Storage IN endpoint
U8  pipe_ms_in;

//! Host start of frame counter incremented under SOF interrupt
volatile U8 host_cpt_sof;



#if (HOST_SYNC_MODE==ENABLE)
   //! directory name for USB out synchro
   U8 code dir_usb_out_name[]=DIR_USB_OUT_NAME;
   //! directory name for USB in synchro
   U8 code dir_usb_in_name[]=DIR_USB_IN_NAME;
   //! directory name for LOCAL out synchro
   U8 code dir_local_out_name[]=DIR_LOCAL_OUT_NAME;
   //! directory name for LOCAL in synchro
   U8 code dir_local_in_name[]=DIR_LOCAL_IN_NAME;
   //! Flag set when sync operation is on-going
   U8 sync_on_going=0;
   //! Intermediate ram unicode file name buffer for sync operation
   U8 ms_str_ram[MAX_FILE_LENGHT];
#endif


//! @brief This function initializes the Host Mass Storage application
//!
//! @param none
//!
//! @return none
void host_ms_task_init(void)
{
   Leds_init();
#if (HOST_SYNC_MODE==ENABLE)
   Joy_init();
#endif
   dms_connected=0;

}

//! @brief This function manages the HOST mass storage application
//!
//!
//! @param none
//!
//! @return none
void host_ms_task(void)
{
U32 capacity;
   U8 new_dms;
   U8 i,k,n,lun;

   if(Is_host_ready())    //Enumeration successfull, device is operationnal
   {
      if(Is_new_device_connection_event())
      {
         for(k=0;k<=Get_nb_device()-1;k++)
      {
            Host_select_device(k);  
            new_dms=TRUE;
         for(i=0;i<Get_nb_supported_interface();i++)
         {
            if(Get_class(i)==MS_CLASS)
            {
               LOG_STR_CODE(log_ms_connect);
                  
                  if (dms_connected!=0) // Other DMS connected ?
                  {
                     for(n=0;n<USB_MAX_DMS_NUMBER;n++) 
                     {
                        if(dms[n].device_index==k) 
                        {
                           new_dms=FALSE;
                        }
                     }
                  }
                  if(new_dms)
                  {
                     dms_connected++;  // TODO check USB_MAX_DMS_NUMBER
                     dms[dms_connected-1].device_index=k;
                     
               //Get correct physical pipes associated to IN/OUT Mass Storage Endpoints
               if(Is_ep_addr_in(Get_ep_addr(i,0)))
               {  //Yes associate it to the MassStorage IN pipe
                        dms[dms_connected-1].pipe_in=usb_tree.device[k].interface[i].ep[0].pipe_number;
                        dms[dms_connected-1].pipe_out=usb_tree.device[k].interface[i].ep[1].pipe_number;
               }
               else
               {  //No, invert...
                        dms[dms_connected-1].pipe_in=usb_tree.device[k].interface[i].ep[1].pipe_number;
                        dms[dms_connected-1].pipe_out=usb_tree.device[k].interface[i].ep[0].pipe_number;
               }
               //Get number of lun in the Device mass storage connected
                     Select_dms(dms_connected-1);
                     dms[dms_connected-1].nb_lun=host_get_lun();
                     //Compute USB lun number
                     lun=0;
                     for(n=0;n<dms_connected-1;n++) 
                     {
                        lun +=dms[n].nb_lun;
                     }                     
               //Initialize all usb drives
                     for(n = 0; n < dms[dms_connected-1].nb_lun; n++)
               {
                  host_ms_inquiry();
                        //host_read_format_capacity(lun); //Some devices require this command beforethe read capacity command
                        host_read_capacity(lun, &capacity);
                  host_ms_request_sense();
                        while (CTRL_GOOD != host_test_unit_ready(lun));
                        host_read_capacity( lun, &capacity );
                        lun++;
               }
               break;
            }
         }
      }
         }
      }

#if (HOST_SYNC_MODE==ENABLE)//Sync operating mode(if available)
      if(Is_joy_right()&&dms_connected)    //Sync device to host stream
      {
         Led0_on();
         sync_on_going=1;
         copy_dir( (U8 code *)dir_usb_out_name,   (U8 code *)dir_local_in_name, 0 );
         sync_on_going=0;
         Led3_off();
         Led0_off();
      }
      if(Is_joy_left()&&dms_connected)   //Sync host to device stream
      {
         Led0_on();
         sync_on_going=1;
         copy_dir( (U8 code *)dir_local_out_name, (U8 code *)dir_usb_in_name, 0 );
         sync_on_going=0;
         Led0_off();
         Led3_off();
      }
#endif
   }
   
   //Device disconnection...
   if(Is_device_disconnection_event())
   {
      for(i=0;i<dms_connected;i++)
      {
         k=dms[i].device_index;
         if(usb_tree.device[k].device_address==0)
         {
            dms_connected--;
            dms[i].device_index=0;
         }
      }
      host_get_lun();
   }
}

//! @brief This function is called each host start of frame, when sync operation
//! is on-going, the function toggles Led3 each 255ms.
//!
//! @param none
//!
//! @return none
void host_sof_action(void)
{
   host_cpt_sof++;
   #if (HOST_SYNC_MODE==ENABLE)
   if(host_cpt_sof==0 &&sync_on_going) Led3_toggle();
   #endif
}

