--- IAR compiler suppport
1) The mcu.h file provides the register definitions required to add support to AT90USB1287
2) The mcu.h operates in pair with the compiler.h
3) Include both files add select "-v3" as "processor configuration" of you IAR project.
4) Please have a look to the complete mouse project file as template file for USB software implementation.  
5) The "lnkm128usb.xcl" file can be use as linker file for the AT90USB1287