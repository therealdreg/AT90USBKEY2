#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>

#ifndef F_CPU
#define F_CPU 8000000UL
#endif
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#include <util/delay.h>

#include <string.h>
#include <stdlib.h>
#include "mmc_avr.h"
#include "diskio.h"

/* File function return code (FRESULT) */

typedef enum 
{
	FR_OK = 0,				/* (0) Succeeded */
	FR_DISK_ERR,			/* (1) A hard error occurred in the low level disk I/O layer */
	FR_INT_ERR,				/* (2) Assertion failed */
	FR_NOT_READY,			/* (3) The physical drive cannot work */
	FR_NO_FILE,				/* (4) Could not find the file */
	FR_NO_PATH,				/* (5) Could not find the path */
	FR_INVALID_NAME,		/* (6) The path name format is invalid */
	FR_DENIED,				/* (7) Access denied due to prohibited access or directory full */
	FR_EXIST,				/* (8) Access denied due to prohibited access */
	FR_INVALID_OBJECT,		/* (9) The file/directory object is invalid */
	FR_WRITE_PROTECTED,		/* (10) The physical drive is write protected */
	FR_INVALID_DRIVE,		/* (11) The logical drive number is invalid */
	FR_NOT_ENABLED,			/* (12) The volume has no work area */
	FR_NO_FILESYSTEM,		/* (13) There is no valid FAT volume */
	FR_MKFS_ABORTED,		/* (14) The f_mkfs() aborted due to any problem */
	FR_TIMEOUT,				/* (15) Could not get a grant to access the volume within defined period */
	FR_LOCKED,				/* (16) The operation is rejected according to the file sharing policy */
	FR_NOT_ENOUGH_CORE,		/* (17) LFN working buffer could not be allocated */
	FR_TOO_MANY_OPEN_FILES,	/* (18) Number of open files > FF_FS_LOCK */
	FR_INVALID_PARAMETER	/* (19) Given parameter is invalid */
} FRESULT;

volatile UINT Timer;	/* Performance timer (100Hz increment) */

void init_uart(void)
{
	UCSR1B |= (1 << TXEN1) | (1 << RXEN1);
	UBRR1L = BAUD_PRESCALE;
	UBRR1H = (BAUD_PRESCALE >> 8);
	UCSR1C = (0<<UMSEL11)|(0<<UMSEL10)|(0<<UPM11)|(0<<UPM10)|
	(0<<USBS1)|(0<<UCSZ12)|(1<<UCSZ11)|(1<<UCSZ10);
}

void uart_putc(unsigned char c)
{
	while( !(UCSR1A & (1 << UDRE1)) );
	UDR1 = c;
}

void uart_puts(char *s)
{
	uint8_t last = 0;
	
	while(*s)
	{
		if ((*s == '\n') && (last != '\r'))
		{
			uart_putc('\r');
			uart_putc('\n');
		}
		else
		{
			uart_putc(*s);
		}
		last = *s;
		s++;
	}
}

void uart_printhex(char *buff, size_t size)
{
	const char hex[] = "0123456789ABCDEF";
    int i;
	
    for(i = 0; i < size; i++)
	{
        uart_putc(hex[(*buff>>4)&0xF]);
        uart_putc(hex[(*buff++)&0xF]);
        uart_putc(' ');
    }
	uart_puts("\n");
}

void uart_printoa(uint32_t number, int base)
{
	char buffer[50];
	
	memset(buffer, 0, sizeof(buffer));
	
	itoa(number, buffer, base);
	
	uart_puts(buffer);
}

void uart_printdecint32(uint32_t number)
{
	uart_printoa(number, 10);
} 

void uart_printhexint32(uint32_t number)
{
	uart_printoa(number, 16);
}

void uart_printbinint32(uint32_t number)
{
	uart_printoa(number, 2);
}

static void ioinit (void)
{
	//MCUCR = _BV(JTD); MCUCR = _BV(JTD);	/* Disable JTAG */

	//pull up 
	
	PORTA = 0b11111111;
	PORTB = 0b11111111;
	PORTC = 0b11111111;
	PORTD = 0b11111111;
	//PORTE = 0b11111111;
	PORTF = 0b11111111;
	//PORTG = 0b00011111;
	
	/* Start 100Hz system timer with TC0 
	OCR2A = F_CPU / 1024 / 100 - 1; //0x4E;
	TCCR2A |= (1 << WGM12);
	TCCR2B |= (1 << CS22) | (1 << CS21) | (1 << CS20);
	TIMSK2 |= (1<<OCIE2A);
	*/
	
	OCR0A = F_CPU / 1024 / 100 - 1;
	TCCR0A = _BV(WGM01);
	TCCR0B = 0b101;
	TIMSK0 = _BV(OCIE0A);
	
	
	sei();
}

ISR(TIMER0_COMPA_vect)
{
	Timer++;			/* Performance counter for this module */
	disk_timerproc();	/* Drive timer procedure of low level disk I/O module */
}

int main(int argc, char **argv)
{	
	uint8_t readed_sector[512];
	uint8_t two_first_sectors[512 * 2];
	FRESULT fr;
	uint32_t current_sector;
	
	MCUSR &= ~(1<<WDRF);
	wdt_disable();
	
	CLKPR = (1<<CLKPCE);
	CLKPR = 0;
	
	ioinit();		
	init_uart();
	
	uart_puts("\n\n");
	
	uart_puts("hellow dreg \n");

	fr = disk_initialize(0);
	if(fr == FR_OK)
	{
		uart_puts("success \n");
	}
	
	memset(two_first_sectors, 0, sizeof(two_first_sectors));
	uart_puts("two first sectors:\n");
	disk_read(0, two_first_sectors, 0, 2);
	uart_printhex(two_first_sectors, sizeof(two_first_sectors));
	_delay_ms(2000);
	
	uart_puts("\nprinting all sectors from 0:\n");
	current_sector = 0;
	while(1)
	{
		uart_puts("\nreaded sector ");
		uart_printdecint32(current_sector);
		uart_puts(" , 0x");
		uart_printhexint32(current_sector);
		uart_puts(" , ");
		uart_printbinint32(current_sector);
		uart_puts("b\n");
		memset(readed_sector, 0, sizeof(readed_sector));
		disk_read(0, readed_sector, current_sector++, 1);
		uart_printhex(readed_sector, sizeof(readed_sector));
		_delay_ms(2000);
		
	}
	
	return 0;
}
