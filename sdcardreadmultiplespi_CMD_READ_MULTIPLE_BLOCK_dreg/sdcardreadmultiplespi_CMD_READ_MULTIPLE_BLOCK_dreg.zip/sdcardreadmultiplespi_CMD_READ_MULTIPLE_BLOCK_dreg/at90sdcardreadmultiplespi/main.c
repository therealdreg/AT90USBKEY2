#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>

#ifndef F_CPU
#define F_CPU 8000000UL
#endif
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#include <util/delay.h>

#include <string.h>
#include <stdlib.h>

#include "sd_raw.h"


void init_uart(void)
{
	UCSR1B |= (1 << TXEN1) | (1 << RXEN1);
	UBRR1L = BAUD_PRESCALE;
	UBRR1H = (BAUD_PRESCALE >> 8);
	UCSR1C = (0<<UMSEL11)|(0<<UMSEL10)|(0<<UPM11)|(0<<UPM10)|
	(0<<USBS1)|(0<<UCSZ12)|(1<<UCSZ11)|(1<<UCSZ10);
}

void uart_putc(unsigned char c)
{
	while( !(UCSR1A & (1 << UDRE1)) );
	UDR1 = c;
}

void uart_puts(char *s)
{
	uint8_t last = 0;
	
	while(*s)
	{
		if ((*s == '\n') && (last != '\r'))
		{
			uart_putc('\r');
			uart_putc('\n');
		}
		else
		{
			uart_putc(*s);
		}
		last = *s;
		s++;
	}
}

void uart_printhex(char *buff, size_t size)
{
	const char hex[] = "0123456789ABCDEF";
	int i;
	
	for(i = 0; i < size; i++)
	{
		uart_putc(hex[(*buff>>4)&0xF]);
		uart_putc(hex[(*buff++)&0xF]);
		uart_putc(' ');
	}
	uart_puts("\n");
}

void uart_printoa(uint32_t number, int base)
{
	char buffer[50];
	
	memset(buffer, 0, sizeof(buffer));
	
	itoa(number, buffer, base);
	
	uart_puts(buffer);
}

void uart_printdecint32(uint32_t number)
{
	uart_printoa(number, 10);
}

void uart_printhexint32(uint32_t number)
{
	uart_printoa(number, 16);
}

void uart_printbinint32(uint32_t number)
{
	uart_printoa(number, 2);
}

void printsector(uint8_t* sector, uint32_t sector_nr)
{
	uart_puts("\nreaded sector ");
	uart_printdecint32(sector_nr);
	uart_puts(" , 0x");
	uart_printhexint32(sector_nr);
	uart_puts(" , ");
	uart_printbinint32(sector_nr);
	uart_puts("b\n");
	uart_printhex((char*) sector, 512);
	
	//_delay_ms(2000);
}

void printsectors(uint8_t* sector, uint32_t first_sector_nr, uint32_t sectors_nr)
{
	int i;
	
	for (i = 0; i < sectors_nr; i++)
	{
		printsector(sector, first_sector_nr++);
		sector += 512;
	}
}

uint8_t callback_read_sect(uint8_t* chunk, void* arg)
{
	static int cnt = 0;
	
	if (cnt % (512 / 64) == 0)
	{
		uart_puts("\nnew block!!\n");
	}
	uart_puts("chunk recived:\n");
	uart_printhex((char*)chunk, 64);
	
	cnt++;
	
	return 1;
}


int main(void)
{
	int i;
	uint8_t ten_first_sectors[512 * 10];
	uint8_t first_sector[512];
	uint8_t first_sector_again[512];
	
	MCUSR &= ~(1<<WDRF);
	wdt_disable();
		
	CLKPR = (1<<CLKPCE);
	CLKPR = 0;

	init_uart();
		
	while(!sd_raw_init())
	{
		uart_puts("\n\nMMC/SD initialization failed\n\n");
	}
	uart_puts("\n\nMMC/SD SUCCESS initialization\n\n");
	
	for (i = 0; i < 3; i++)
	{
		memset(first_sector_again, 0, sizeof(first_sector_again));
		memset(first_sector, 0, sizeof(first_sector));
		memset(ten_first_sectors, 0, sizeof(ten_first_sectors));
	
		sd_raw_read(0, first_sector, 512);
	
		sd_raw_initmultiread(0);
		sd_raw_multiread(ten_first_sectors, 10);
		sd_raw_stopmulti();
	
		sd_raw_read(0, first_sector_again, 512);
		
		uart_puts("\nfirst sector with CMD_READ_SINGLE_BLOCK(0x11)\n");
		printsector(first_sector, 1);
	
		uart_puts("\nfirst ten sectors with CMD_READ_MULTIPLE_BLOCK(0x12)\n");
		printsectors(ten_first_sectors, 0, 10);

		uart_puts("\nAGAIN first sector with CMD_READ_SINGLE_BLOCK(0x11)\n");
		printsector(first_sector_again, 1);

		uart_puts("\nreading first three sectors with CALLBACK_INTERVAL(64) using CMD_READ_MULTIPLE_BLOCK(0x12)\n");
		sd_raw_initmultiread(0);
		sd_raw_multireadCbinterval(3, 64, callback_read_sect, NULL);
		sd_raw_stopmulti();
	}

		
    while (1) 
    {
    }
	
	return 0;
}

