var a00056 =
[
    [ "Config", "a00056.html#a19776357dd07e9e13999216afe193191", null ],
    [ "HID_KeyboardHID", "a00056.html#a0b67de014d0b5588b5eba306b0839dac", null ],
    [ "HID_KeyboardInterface", "a00056.html#ae03914c6bd4705f2cbff809772027db0", null ],
    [ "HID_ReportINEndpoint", "a00056.html#a6e43ccff744671be43d6fe978953ceb7", null ],
    [ "MS_DataInEndpoint", "a00056.html#ab7bad6cc3d4e205acc5c039e996dddc6", null ],
    [ "MS_DataOutEndpoint", "a00056.html#a8627bb8be7561cc6c8fe5a36cea51be0", null ],
    [ "MS_Interface", "a00056.html#aad95c090a032dc5bc0054ca48d6c0fb6", null ]
];