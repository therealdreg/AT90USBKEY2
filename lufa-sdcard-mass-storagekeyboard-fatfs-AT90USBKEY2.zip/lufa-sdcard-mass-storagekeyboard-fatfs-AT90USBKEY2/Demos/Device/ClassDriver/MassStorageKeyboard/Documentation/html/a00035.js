var a00035 =
[
    [ "DATA_READ", "a00035.html#ab2f24d71b50144885a0f182b6d2e274a", null ],
    [ "DATA_WRITE", "a00035.html#a1033012652c8143c410c1b30f1dc5af0", null ],
    [ "DEVICE_TYPE_BLOCK", "a00035.html#a89cd973fab7f69a278db6df0dee58f4a", null ],
    [ "DEVICE_TYPE_CDROM", "a00035.html#ae5f394b1c3dc9020f7821786d4129444", null ],
    [ "SCSI_SET_SENSE", "a00035.html#a89b450bcd29ca2f542ed59d3ceab5aeb", null ],
    [ "SCSI_DecodeSCSICommand", "a00035.html#a3b71f7f089feea74b0e8524c9b79d126", null ]
];