var a00047 =
[
    [ "LEDMASK_USB_BUSY", "a00047.html#a8e041687ba6fa46320c904de65419fa8", null ],
    [ "LEDMASK_USB_ENUMERATING", "a00047.html#ae5f555e6ba3f29cf2683653715b2882b", null ],
    [ "LEDMASK_USB_ERROR", "a00047.html#a9c02d2f661a67e5d895a637b1786e495", null ],
    [ "LEDMASK_USB_NOTREADY", "a00047.html#a35a06cf522ba5b8ef837c8c5e0bee17b", null ],
    [ "LEDMASK_USB_READY", "a00047.html#a1bdfeb2384ab943afb611716fb2034ee", null ],
    [ "CALLBACK_HID_Device_CreateHIDReport", "a00047.html#add1d70f5c793ae44213cf3e26f58cbfe", null ],
    [ "CALLBACK_HID_Device_ProcessHIDReport", "a00047.html#ad6a35266e845267f6bffe0a4e9da3839", null ],
    [ "CALLBACK_MS_Device_SCSICommandReceived", "a00047.html#a2ab82a996fd4af66f7359e75688e2c0d", null ],
    [ "EVENT_USB_Device_ConfigurationChanged", "a00047.html#a953a275884b9e33629ff6323fca05252", null ],
    [ "EVENT_USB_Device_Connect", "a00047.html#aeff97648c9250a3d398bb0b74f040899", null ],
    [ "EVENT_USB_Device_ControlRequest", "a00047.html#a3f4ce439a74a152e3c8ffda5c7dd201a", null ],
    [ "EVENT_USB_Device_Disconnect", "a00047.html#ae88405d14d8d6dada9313520cb1501ec", null ],
    [ "EVENT_USB_Device_StartOfFrame", "a00047.html#aa3ebb4fd4403f463b300b745d8485b65", null ],
    [ "SetupHardware", "a00047.html#acb27e569c06a2797c5fd58ed39147448", null ]
];