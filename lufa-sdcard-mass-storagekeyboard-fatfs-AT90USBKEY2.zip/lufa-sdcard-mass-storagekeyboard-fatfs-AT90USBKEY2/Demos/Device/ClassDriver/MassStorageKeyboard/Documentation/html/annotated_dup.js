var annotated_dup =
[
    [ "SDIO_CTRL", "a00060.html", "a00060" ],
    [ "USB_Descriptor_Configuration_t", "a00056.html", "a00056" ]
];