var a00060 =
[
    [ "addr", "a00060.html#a15025848d3f3733f366504d30a1d9bb2", null ],
    [ "data", "a00060.html#ab04c9adb4d3027a14925fb30b469f0c0", null ],
    [ "func", "a00060.html#a2f0a17848a6c7c58f826d1888469e6e3", null ],
    [ "ndata", "a00060.html#a44edc7d37688ac4f3a1ba3d66e909767", null ]
];