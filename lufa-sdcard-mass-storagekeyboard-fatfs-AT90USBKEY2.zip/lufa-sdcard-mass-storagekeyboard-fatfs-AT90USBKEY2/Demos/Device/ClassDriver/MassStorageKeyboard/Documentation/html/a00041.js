var a00041 =
[
    [ "LUN_MEDIA_BLOCKS", "a00041.html#a74ba398e7640ffa25cfd45e346ba7c17", null ],
    [ "VIRTUAL_MEMORY_BLOCK_SIZE", "a00041.html#a46b701cd2078c2091bd4678e38ce8e64", null ],
    [ "SDCardManager_CheckDataflashOperation", "a00041.html#a441c554c387fe631072ed6ff86be338a", null ],
    [ "SDCardManager_GetNbBlocks", "a00041.html#ab39609585ea010fa81a6890da227d325", null ],
    [ "SDCardManager_Init", "a00041.html#acca0eec5604dd35c4bca14fdbf57bb40", null ],
    [ "SDCardManager_ReadBlocks", "a00041.html#a65133cbbf3d64b8de195cc9455d4655b", null ],
    [ "SDCardManager_ResetDataflashProtections", "a00041.html#ab1c3807e77fc5b1b06948225e850c5fe", null ],
    [ "SDCardManager_WriteBlocks", "a00041.html#a514f61c0b6df27dbe814698f5c8c96b2", null ],
    [ "SDCardManager_WriteBlocks_RAM", "a00041.html#a6ba8f005e340887be8b39d245412434c", null ],
    [ "SDCardManagerManager_ReadBlocks_RAM", "a00041.html#a3437ccfce997519aa7960d36001025d8", null ]
];