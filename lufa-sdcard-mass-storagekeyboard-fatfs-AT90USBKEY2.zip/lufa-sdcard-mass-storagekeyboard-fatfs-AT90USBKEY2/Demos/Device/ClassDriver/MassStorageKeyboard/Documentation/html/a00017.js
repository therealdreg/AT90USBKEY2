var a00017 =
[
    [ "disk_initialize", "a00017.html#a09cdaa6f36fa409bdf002727bff98eb1", null ],
    [ "disk_ioctl", "a00017.html#ab00fa450a811dbdabe3c655c1a36fab4", null ],
    [ "disk_read", "a00017.html#a075d27f59f550e2cee07d00abcff32e0", null ],
    [ "disk_status", "a00017.html#a8348ac5ee6d709420c02e45c111f4793", null ],
    [ "disk_timerproc", "a00017.html#a045f8898a243c16aca4e64e069c49c03", null ],
    [ "disk_write", "a00017.html#a0fe56ee4831a44b09cfd96856e069634", null ]
];