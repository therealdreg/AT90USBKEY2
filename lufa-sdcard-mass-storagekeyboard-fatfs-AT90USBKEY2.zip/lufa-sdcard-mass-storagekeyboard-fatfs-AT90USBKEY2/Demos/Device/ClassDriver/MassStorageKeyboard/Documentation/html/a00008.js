var a00008 =
[
    [ "CALLBACK_USB_GetDescriptor", "a00008.html#aa0890c5e991cffc64420173f6bd6c623", null ],
    [ "ConfigurationDescriptor", "a00008.html#a2f9990582f9f77c84f9fd5e17f06ef94", null ],
    [ "DeviceDescriptor", "a00008.html#a0459e2e95322791f208b3ec95eeacd67", null ],
    [ "KeyboardReport", "a00008.html#a759d99f07fc166aae843481d3770be2c", null ],
    [ "LanguageString", "a00008.html#a66db23e38bbdd9349a152aac33d434be", null ],
    [ "ManufacturerString", "a00008.html#a7d6ed4ecd8df8a89c81f4dafdea2a044", null ],
    [ "ProductString", "a00008.html#a8e0e3f9f3beab42d693f676fdcaebe7d", null ]
];