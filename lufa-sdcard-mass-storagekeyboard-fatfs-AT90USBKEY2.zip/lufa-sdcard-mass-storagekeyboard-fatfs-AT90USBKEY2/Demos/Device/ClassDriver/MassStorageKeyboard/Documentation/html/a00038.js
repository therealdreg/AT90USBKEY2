var a00038 =
[
    [ "SDCardManager_CheckDataflashOperation", "a00038.html#a441c554c387fe631072ed6ff86be338a", null ],
    [ "SDCardManager_GetNbBlocks", "a00038.html#ab39609585ea010fa81a6890da227d325", null ],
    [ "SDCardManager_Init", "a00038.html#acca0eec5604dd35c4bca14fdbf57bb40", null ],
    [ "SDCardManager_ReadBlockHandler", "a00038.html#aebfd444fa6da4e57ee27eadfe5f11926", null ],
    [ "SDCardManager_ReadBlocks", "a00038.html#a65133cbbf3d64b8de195cc9455d4655b", null ],
    [ "SDCardManager_WriteBlockHandler", "a00038.html#abbcba6e2db4b64726088d0fe037b0873", null ],
    [ "SDCardManager_WriteBlocks", "a00038.html#aacb8a47c46e8a5e6abd8cf6f0c979b37", null ],
    [ "CachedTotalBlocks", "a00038.html#ad19aef74a5b727e76ddd23bd10b710f6", null ]
];