var a00011 =
[
    [ "USB_Descriptor_Configuration_t", "a00056.html", "a00056" ],
    [ "KEYBOARD_EPADDR", "a00011.html#a049d767b99b6186e61ae725c1f1b1c7d", null ],
    [ "KEYBOARD_EPSIZE", "a00011.html#a843a9b3503fe51e869c788b661034904", null ],
    [ "MASS_STORAGE_IN_EPADDR", "a00011.html#ae57ba72c039d6ab58e88876dbc704105", null ],
    [ "MASS_STORAGE_IO_EPSIZE", "a00011.html#a6d6f5e4870ef17a2f4c17570f85192c0", null ],
    [ "MASS_STORAGE_OUT_EPADDR", "a00011.html#a204a1e48dab7e7ce2f0c522bb224b8ed", null ],
    [ "InterfaceDescriptors_t", "a00011.html#ab083ca8c92e1a34d1952524ae96df991", [
      [ "INTERFACE_ID_MassStorage", "a00011.html#ab083ca8c92e1a34d1952524ae96df991a257ff358d8ece3d78e569efc85e732dd", null ],
      [ "INTERFACE_ID_Keyboard", "a00011.html#ab083ca8c92e1a34d1952524ae96df991ac61bb02b4b816b592e3ef998331a1b36", null ]
    ] ],
    [ "StringDescriptors_t", "a00011.html#a21cbe47ab5f841fd15ee59d8017936d8", [
      [ "STRING_ID_Language", "a00011.html#a21cbe47ab5f841fd15ee59d8017936d8a43c26110f583bb49be4f8ae366dd7e92", null ],
      [ "STRING_ID_Manufacturer", "a00011.html#a21cbe47ab5f841fd15ee59d8017936d8a651601e2a5c0024a03f17deb9cba5fd6", null ],
      [ "STRING_ID_Product", "a00011.html#a21cbe47ab5f841fd15ee59d8017936d8a607e2bb4530983e92ad33b532ea65fed", null ]
    ] ],
    [ "CALLBACK_USB_GetDescriptor", "a00011.html#af8c2dd70ada32eb9017d08afc75543b2", null ]
];