var files_dup =
[
    [ "Config", "dir_894de4897dae893eb9d15381d999f0a0.html", "dir_894de4897dae893eb9d15381d999f0a0" ],
    [ "Lib", "dir_8f3de2ae926fecfe6abd5379fd2b6eb1.html", "dir_8f3de2ae926fecfe6abd5379fd2b6eb1" ],
    [ "Descriptors.c", "a00008.html", "a00008" ],
    [ "Descriptors.h", "a00011.html", "a00011" ],
    [ "MassStorageKeyboard.c", "a00044.html", "a00044" ],
    [ "MassStorageKeyboard.h", "a00047.html", "a00047" ]
];