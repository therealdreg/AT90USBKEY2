var a00023 =
[
    [ "BYTE", "a00023.html#a4ae1dab0fb4b072a66584546209e7d58", null ],
    [ "DWORD", "a00023.html#ad342ac907eb044443153a22f964bf0af", null ],
    [ "INT", "a00023.html#a392e62da233ed3e2f7c3fd4f487a3896", null ],
    [ "LONG", "a00023.html#a2a3e0cda5f1249bef6db47c5eb8e3813", null ],
    [ "QWORD", "a00023.html#a6fe04fdd875bcad282f702bb818897b6", null ],
    [ "SHORT", "a00023.html#a9909bd3cf05f0906045f2ee85be4eeac", null ],
    [ "UINT", "a00023.html#a36cb3b01d81ffd844bbbfb54003e06ec", null ],
    [ "WCHAR", "a00023.html#a570001c92f314285ad3e7139d8c58cf7", null ],
    [ "WORD", "a00023.html#a197942eefa7db30960ae396d68339b97", null ]
];