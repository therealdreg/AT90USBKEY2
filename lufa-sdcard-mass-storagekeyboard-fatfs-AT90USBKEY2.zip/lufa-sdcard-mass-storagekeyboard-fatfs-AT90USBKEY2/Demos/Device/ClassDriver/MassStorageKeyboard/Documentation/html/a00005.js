var a00005 =
[
    [ "FIXED_CONTROL_ENDPOINT_SIZE", "a00005.html#a94173e25c382d0261cb5be6312f9c6b7", null ],
    [ "FIXED_NUM_CONFIGURATIONS", "a00005.html#ac67524e986b10e9a1eb5c190863c5c7d", null ],
    [ "INTERRUPT_CONTROL_ENDPOINT", "a00005.html#a8322aa284ea72089e41750fb5f666ccf", null ],
    [ "USB_DEVICE_ONLY", "a00005.html#a0ea40b95bddb7eae247d3d91f5517d79", null ],
    [ "USE_FLASH_DESCRIPTORS", "a00005.html#a62b9d6f45fd422c7ba2957a67752a31b", null ],
    [ "USE_STATIC_OPTIONS", "a00005.html#a7b4f2c7fd2749f6c278416edefd7de3d", null ]
];