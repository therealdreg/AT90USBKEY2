var a00002 =
[
    [ "DISK_READ_ONLY", "a00002.html#a8bbf5d8cbc2b7f0f5e0ac0d200cf234a", null ],
    [ "TOTAL_LUNS", "a00002.html#a50367256bfbc0d0b9d6fd42fb63e78a9", null ]
];