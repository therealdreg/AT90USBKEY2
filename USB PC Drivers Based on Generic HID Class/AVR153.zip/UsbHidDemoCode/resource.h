//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UsbHidDemoCode.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USBHIDDEMOCODE_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDB_GREY_LED                    131
#define IDB_GREEN_LED                   132
#define IDC_LED1                        1000
#define IDC_LED2                        1001
#define IDC_LED3                        1002
#define IDC_LED4                        1003
#define IDC_STATIC_VID                  1004
#define IDC_VID                         1005
#define IDC_STATIC_PID                  1006
#define IDC_PID                         1007
#define IDC_PW_UPGRADE                  1008
#define IDC_FW_UPGRADE                  1008
#define IDC_STATUS                      1011
#define IDC_STATUS_TEXT                 1012
#define IDC_LIST                        1013
#define IDC_BUTTON_VID_PID              1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
